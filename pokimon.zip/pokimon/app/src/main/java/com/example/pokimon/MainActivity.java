package com.example.pokimon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<pokimon>  pokeball = new ArrayList<>();

        pokimon s1 = new pokimon("Venusaur",100,123,625);
        pokimon s2 = new pokimon("Charizardr",78,78,534);
        pokimon s3 = new pokimon("Bulbasaur",49,49,525);
        pokimon s4 = new pokimon("Butterfree",45,50,395);
        pokimon s5 = new pokimon("Weedle",35,30,195);

        pokeball.add(s1);//0
        pokeball.add(s2);//1
        pokeball.add(s3);//2
        pokeball.add(s4);//3
        pokeball.add(s5);//4

        RecyclerView a = findViewById(R.id.recclerview);

    }
}
package com.example.pokimon;

public class pokimon {

    private String Pokédex ;
    private int attack = 48 ;
    private int dedens = 65 ;
    private int total = 314 ;

    public pokimon(String pokédex, int attack, int dedens, int total) {
        Pokédex = pokédex;
        this.attack = attack;
        this.dedens = dedens;
        this.total = total;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDedens() {
        return dedens;
    }

    public void setDedens(int dedens) {
        this.dedens = dedens;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getPokédex() {
        return Pokédex;
    }

    public void setPokédex(String pokédex) {
        Pokédex = pokédex;
    }

    public pokimon(String pokédex) {
        Pokédex = pokédex;
    }
}
